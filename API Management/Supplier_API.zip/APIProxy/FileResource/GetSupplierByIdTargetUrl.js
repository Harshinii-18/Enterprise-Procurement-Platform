var targetUrl = context.getVariable("target.url");
var supplierId = context.getVariable("supplierId");

context.setVariable("target.url", targetUrl + "?resource=suppliers&id=" + supplierId);