var targetUrl = context.getVariable("target.url");

context.setVariable("original.request.uri",
                    context.getVariable("request.uri"));
context.setVariable("target.url", targetUrl);
context.setVariable("target.copy.pathsuffix",false);