var targetUrl = context.getVariable("target.url");
var employeeId = context.getVariable("employeeId");

context.setVariable("target.url", targetUrl + "?resource=employees&id=" + employeeId);