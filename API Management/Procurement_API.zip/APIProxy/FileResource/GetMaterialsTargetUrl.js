var targetUrl = context.getVariable("target.url");

context.setVariable("target.url", targetUrl + "?resource=materials");