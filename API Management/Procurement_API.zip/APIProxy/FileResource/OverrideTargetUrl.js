var targetUrl = context.getVariable("target.url");

context.setVariable("target.url", targetUrl);
context.setVariable("target.copy.pathsuffix",false);