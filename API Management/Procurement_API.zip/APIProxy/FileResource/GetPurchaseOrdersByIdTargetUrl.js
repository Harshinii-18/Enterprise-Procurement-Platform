var targetUrl = context.getVariable("target.url");
var purchaseOrderId = context.getVariable("purchaseOrderId");

context.setVariable("target.url", targetUrl + "?resource=purchase-orders&id=" + purchaseOrderId);